# New Horizons
New Horizons is an easy way to install

1. JupyterLab
1. Elyra
1. KubeFlow Pipelines
1. ApacheSpark

to any Kubernetes environment.

In addition, KIND - Kubernetes in Docker - can be installed as well. Therefore, the only pre-requisites for running *New Horizons* are:

1. A working *docker* installation
1. The *git* command line tool
