docker build -t elyra-ai .

