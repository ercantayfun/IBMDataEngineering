#!/bin/bash
sudo curl -Lo /bin/kind https://github.com/kubernetes-sigs/kind/releases/download/v0.12.0/kind-linux-amd64
sudo chmod 755 /bin/kind
